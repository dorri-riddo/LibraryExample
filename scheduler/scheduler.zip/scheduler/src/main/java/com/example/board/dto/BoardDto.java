package com.example.board.dto;

public class BoardDto {
	private int scheduler_report_id;
	private String day;
	
	public int getScheduler_report_id() {
		return scheduler_report_id;
	}
	public void setScheduler_report_id(int scheduler_report_id) {
		this.scheduler_report_id = scheduler_report_id;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
}
